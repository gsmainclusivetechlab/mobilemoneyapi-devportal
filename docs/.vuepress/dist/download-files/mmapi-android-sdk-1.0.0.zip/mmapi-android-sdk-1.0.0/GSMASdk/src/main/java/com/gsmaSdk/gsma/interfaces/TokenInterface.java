package com.gsmaSdk.gsma.interfaces;

import com.gsmaSdk.gsma.models.common.Token;
import com.gsmaSdk.gsma.models.common.GSMAError;

/**
 * Interface for clients to receive Token creation response
 * */
public interface TokenInterface extends BaseInterface {

    void onTokenSuccess(Token token);

    void onTokenFailure(GSMAError gsmaError);
}
