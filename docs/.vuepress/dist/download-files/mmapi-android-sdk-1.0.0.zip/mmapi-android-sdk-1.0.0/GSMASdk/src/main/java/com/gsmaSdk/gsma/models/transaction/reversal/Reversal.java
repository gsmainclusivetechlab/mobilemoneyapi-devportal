package com.gsmaSdk.gsma.models.transaction.reversal;

import com.gsmaSdk.gsma.models.transaction.transactions.Transaction;

public class Reversal extends Transaction {


}
