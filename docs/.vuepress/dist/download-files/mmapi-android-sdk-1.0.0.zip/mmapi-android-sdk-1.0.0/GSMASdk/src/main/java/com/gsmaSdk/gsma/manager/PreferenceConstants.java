package com.gsmaSdk.gsma.manager;

public class PreferenceConstants {
    public static final String TOKEN="token";
}
