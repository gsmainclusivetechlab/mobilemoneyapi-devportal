SDKManager.disbursement.viewBatchTransaction(transactionRef, new BatchTransactionItemInterface() {
  @Override
  public void batchTransactionSuccess(BatchTransaction batchTransactionItem) {
               
  }

  @Override
  public void onTransactionFailure(GSMAError gsmaError) {
               
  }

  @Override
  public void onValidationError(ErrorObject errorObject) {
                
  }
});