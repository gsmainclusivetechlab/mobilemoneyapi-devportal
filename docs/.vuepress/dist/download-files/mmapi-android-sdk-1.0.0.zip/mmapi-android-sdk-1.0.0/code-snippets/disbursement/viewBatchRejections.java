SDKManager.disbursement.viewBatchRejections("REF-1635765084301", new BatchRejectionInterface() {
  @Override
  public void onValidationError(ErrorObject errorObject) {
            
  }

  @Override
  public void batchTransactionRejections(BatchRejections batchTransactionRejection) {
     
  }

  @Override
  public void onTransactionFailure(GSMAError gsmaError) {
        
  }
});