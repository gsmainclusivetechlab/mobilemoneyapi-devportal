SDKManager.internationalTransfer.viewServiceAvailability(new ServiceAvailabilityInterface() {
  @Override
  public void onValidationError(ErrorObject errorObject) {
                
  }

  @Override
  public void onServiceAvailabilitySuccess(ServiceAvailability serviceAvailability) {
  }

  @Override
  public void onServiceAvailabilityFailure(GSMAError gsmaError) {
              
  }
});