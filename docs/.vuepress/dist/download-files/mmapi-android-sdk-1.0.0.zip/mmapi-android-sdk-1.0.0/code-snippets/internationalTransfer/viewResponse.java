SDKManager.internationalTransfer.viewResponse(correlationId, new MissingResponseInterface() {
	@Override
    public void onMissingResponseSuccess(MissingResponse missingResponse) {
    }

    @Override
    public void onMissingResponseFailure(GSMAError gsmaError) {
              
    }

    @Override
    public void onValidationError(ErrorObject errorObject) {
               
    }
});