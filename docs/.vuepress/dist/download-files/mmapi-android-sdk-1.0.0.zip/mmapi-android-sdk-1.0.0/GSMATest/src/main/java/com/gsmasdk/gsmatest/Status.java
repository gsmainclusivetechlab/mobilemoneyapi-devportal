package com.gsmasdk.gsmatest;

public class Status {

  private   int status;

    public int getStatus() {
        return status;
    }


    public void setStatus(int status) {
        this.status = status;
    }
}
