<?php

namespace mmpsdk\Common\Models;

use mmpsdk\Common\Models\BaseModel;

/**
 * Class AuthToken
 * @package mmpsdk\Common\Models
 */
class AuthToken extends BaseModel
{
    private $authToken;
    private $expiresIn;
    private $createdAt;

    public function setAuthToken($authToken)
    {
        $this->authToken = $authToken;
        return $this;
    }
    public function getAuthToken()
    {
        return $this->authToken;
    }
    public function setExpiresIn($expiresIn)
    {
        $this->expiresIn = $expiresIn;
        return $this;
    }
    public function getExpiresIn()
    {
        return $this->expiresIn;
    }
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function jsonSerialize()
    {
        return $this->filterEmpty([
            'authToken' => $this->authToken,
            'expiresIn' => $this->expiresIn,
            'createdAt' => $this->createdAt
        ]);
    }
}
