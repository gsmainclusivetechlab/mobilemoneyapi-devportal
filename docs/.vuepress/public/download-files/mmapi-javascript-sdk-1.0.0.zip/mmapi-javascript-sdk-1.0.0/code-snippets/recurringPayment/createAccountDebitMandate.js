{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "createAccountDebitMandate",
  "data": {
    "payee": [
      {
        "key": "accountId",
        "value": "1"
      }
    ],
    "startDate": "2018-11-20",
    "requestDate": "2021-11-24T12:44:34.223Z"
  },
 "onSuccess":(response, header, status)=>{},
 "onFailure": (response, status) => {}
}