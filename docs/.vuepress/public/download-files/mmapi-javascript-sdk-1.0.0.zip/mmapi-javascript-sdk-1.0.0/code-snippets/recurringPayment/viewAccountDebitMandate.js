{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "mandateReference": "REF-1637758263349",
  "type": "viewAccountDebitMandate"
}