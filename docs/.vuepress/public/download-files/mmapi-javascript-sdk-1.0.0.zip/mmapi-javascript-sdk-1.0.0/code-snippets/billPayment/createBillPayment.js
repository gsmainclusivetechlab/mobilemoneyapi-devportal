{
  "billReference": "REF-000001",
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "type": "createBillPayment",
  "data": {
    "currency": "GBP",
    "amountPaid": "5.30"
  }
}