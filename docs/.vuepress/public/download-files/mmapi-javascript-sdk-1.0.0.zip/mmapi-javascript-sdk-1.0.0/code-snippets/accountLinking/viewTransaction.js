{
   "transactionReference": "REF-1633678194929",
   "type": "viewTransaction"
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}