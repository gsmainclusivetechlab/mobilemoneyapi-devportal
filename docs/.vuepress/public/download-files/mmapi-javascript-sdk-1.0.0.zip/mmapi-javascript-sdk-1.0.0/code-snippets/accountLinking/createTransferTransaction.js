{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "createTransferTransaction",
  "data": {
    "amount": "200.00",
    "creditParty": [
      {
        "key": "linkref",
        "value": "REF-1638168563421"
      }
    ],
    "currency": "RWF",
    "debitParty": [
      {
        "key": "accountid",
        "value": "1"
      }
    ]
  }
}