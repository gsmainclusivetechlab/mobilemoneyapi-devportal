{
  "clientCorrelationId": "cc56daf1-b2dd-4553-aeba-43d61d81f5c8",
  "type": "viewResponse",
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}