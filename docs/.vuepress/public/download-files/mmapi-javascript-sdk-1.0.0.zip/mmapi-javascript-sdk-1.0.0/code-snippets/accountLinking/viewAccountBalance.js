{
    "accountId": [
        {
        "key": "accountid",
        "value": "1"
        }
    ],
    "type": "viewAccountBalance"
   "getClientCorrelationId":(response)=>{},
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}