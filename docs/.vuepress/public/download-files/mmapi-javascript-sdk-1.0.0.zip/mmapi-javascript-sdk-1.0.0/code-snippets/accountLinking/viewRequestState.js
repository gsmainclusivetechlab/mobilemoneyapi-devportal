{
  "serverCorrelationId": "db474b5c-cc9d-4173-b1b0-8ac06cb20e7c",
  "type": "viewRequestState",
   "getClientCorrelationId":(response)=>{},
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}