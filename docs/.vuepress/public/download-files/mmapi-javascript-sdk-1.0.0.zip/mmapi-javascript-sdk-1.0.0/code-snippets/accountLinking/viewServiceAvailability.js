{
  "type": "viewServiceAvailability"
}