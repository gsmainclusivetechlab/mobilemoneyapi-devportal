{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "linkReference": "REF-1638168563421",
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "viewAccountLink"
}