{
   "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
   "transactionReference": "REF-1466171557592",
   "type": "createReversal",
   "getClientCorrelationId":(response)=>{},
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}