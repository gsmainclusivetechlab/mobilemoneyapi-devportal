{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "type": "createAccountLink",
  "data": {
    "sourceAccountIdentifiers": [
      {
        "key": "accountid",
        "value": "2999"
      }
    ],
    "status": "active",
    "mode": "both",
    "customData": [
      {
        "key": "keytest",
        "value": "keyvalue"
      }
    ],
    "requestingOrganisation": {
      "requestingOrganisationIdentifierType": "organisationid",
      "requestingOrganisationIdentifier": "12345"
    }
  }
}
