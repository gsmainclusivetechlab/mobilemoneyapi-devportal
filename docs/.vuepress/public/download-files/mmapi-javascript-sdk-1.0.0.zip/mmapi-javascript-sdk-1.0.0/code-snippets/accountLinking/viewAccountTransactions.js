{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "filter": [
    {
      "key": "offset",
      "value": "0"
    },
    {
      "key": "limit",
      "value": "2"
    }
  ],
  "type": "viewAccountTransaction"
}