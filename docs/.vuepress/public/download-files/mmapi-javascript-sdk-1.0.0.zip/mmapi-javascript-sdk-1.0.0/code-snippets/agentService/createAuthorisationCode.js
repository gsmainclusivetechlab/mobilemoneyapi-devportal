{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "createAuthorisationCode",
  "data": {
    "requestDate": "2018-07-03T10:43:27.405Z",
    "currency": "GBP",
    "amount": "1000.00"
  }
}