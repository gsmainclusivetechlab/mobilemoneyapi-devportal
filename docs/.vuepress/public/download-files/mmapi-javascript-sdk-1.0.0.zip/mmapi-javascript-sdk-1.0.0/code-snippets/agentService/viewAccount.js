{
  "accountId": [
    {
      "key": "msisdn",
      "value": "+447777777774"
    }
  ],
  "type": "viewAccount"
}