{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "createDepositTransaction",
  "data": {
    "amount": "200.00",
    "debitParty": [
      {
        "key": "accountid",
        "value": "2999"
      }
    ],
    "creditParty": [
      {
        "key": "accountid",
        "value": "2999"
      }
    ],
    "currency": "RWF"
  }
}