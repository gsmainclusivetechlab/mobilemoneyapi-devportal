{
  "authorisationCode": "059f88cc-c4c8-4e48-9388-0c3abb7b329b",
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "type": "viewAuthorisationCode"
}