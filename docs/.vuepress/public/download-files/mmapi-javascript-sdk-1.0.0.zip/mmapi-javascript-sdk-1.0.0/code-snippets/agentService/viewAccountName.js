{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "type": "viewAccountName"
}