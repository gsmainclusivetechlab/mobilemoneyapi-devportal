{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "transactionReference": "REF-1640674886743",
  "type": "createReversal"
}