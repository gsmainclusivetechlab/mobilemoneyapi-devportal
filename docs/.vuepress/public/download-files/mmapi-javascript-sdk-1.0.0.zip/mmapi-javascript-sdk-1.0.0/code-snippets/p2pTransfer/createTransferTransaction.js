{
  "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
  "type": "createTransferTransaction",
  "data": {
    "amount": "200.00",
    "debitParty": [
      {
        "key": "accountid",
        "value": "1"
      }
    ],
    "creditParty": [
      {
        "key": "accountid",
        "value": "30"
      }
    ],
    "currency": "RWF"
  }
}