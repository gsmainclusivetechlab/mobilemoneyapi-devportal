{
   "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "authorisationCode": "7006e6d7-d0e4-4cda-9300-8cb42bbf8915",
  "type": "viewAuthorisationCode",
   "onSuccess":(response, header, status)=>{},
   "onFailure": (response, status) => {}
}