{
  "accountId": [
    {
      "key": "accountid",
      "value": "1"
    }
  ],
  "data": {
    "amount": "200.00",
    "debitParty": [
      {
        "key": "accountid",
        "value": "1"
      }
    ],
    "creditParty": [
      {
        "key": "accountid",
        "value": "30"
      }
    ],
    "currency": "RWF",
    "oneTimeCode": "e8f51f4e-c8d6-4b4e-873b-fcdbda22523d"
  },
 "callbackUrl": "https://end13wxm5t7fgd6.m.pipedream.net/",
 "type": "createMerchantTransaction",
 "getClientCorrelationId":(response)=>{},
 "onSuccess":(response, header, status)=>{},
 "onFailure": (response, status) => {}
}