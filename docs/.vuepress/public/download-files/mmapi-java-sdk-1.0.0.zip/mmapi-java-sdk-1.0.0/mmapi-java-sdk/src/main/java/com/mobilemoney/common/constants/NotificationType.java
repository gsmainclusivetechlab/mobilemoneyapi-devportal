package com.mobilemoney.common.constants;

/***
 *
 */
public enum NotificationType {
    CALLBACK,
    POLLING
}
