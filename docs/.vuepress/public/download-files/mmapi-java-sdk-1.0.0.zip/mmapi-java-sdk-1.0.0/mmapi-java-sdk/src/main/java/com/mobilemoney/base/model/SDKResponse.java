package com.mobilemoney.base.model;

public interface SDKResponse {
}
