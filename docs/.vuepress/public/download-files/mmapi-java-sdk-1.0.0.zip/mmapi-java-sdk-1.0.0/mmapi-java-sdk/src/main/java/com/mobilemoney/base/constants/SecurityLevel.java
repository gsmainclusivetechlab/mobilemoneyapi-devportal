package com.mobilemoney.base.constants;

/***
 * Security level list
 */
public enum SecurityLevel {
    NONE,
    DEVELOPMENT,
    STANDARD,
    ENHANCED
}
