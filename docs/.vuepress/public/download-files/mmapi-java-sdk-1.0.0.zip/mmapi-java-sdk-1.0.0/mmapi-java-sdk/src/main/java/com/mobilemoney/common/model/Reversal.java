package com.mobilemoney.common.model;

import java.io.Serializable;

/***
 * 
 * Class Reversal
 *
 */
public class Reversal extends Transaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2370459655616422788L;

}
