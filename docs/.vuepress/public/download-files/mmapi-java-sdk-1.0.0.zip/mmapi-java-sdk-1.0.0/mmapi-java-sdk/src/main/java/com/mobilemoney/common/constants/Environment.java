package com.mobilemoney.common.constants;

/***
 * Environment
 */
public enum Environment {
    SANDBOX,
    PRODUCTION
}
